package com.example.trabalho_parcial

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
