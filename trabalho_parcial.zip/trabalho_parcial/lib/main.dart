import 'package:flutter/material.dart';
import 'package:device_preview/device_preview.dart';
import 'package:trabalho_parcial/view/Listas.dart';
import 'package:trabalho_parcial/view/Nova_lista.dart';
import 'package:trabalho_parcial/view/login.dart';
import 'package:trabalho_parcial/view/criar_us.dart';
import 'package:trabalho_parcial/view/sobre.dart';
import 'package:trabalho_parcial/view/App.dart';
import 'package:trabalho_parcial/view/LstComp.dart';
import 'package:trabalho_parcial/view/Novo_item.dart';
import 'package:trabalho_parcial/view/Mudar_Nome.dart';
import 'package:trabalho_parcial/view/Mudar_Item.dart';

void main() {
  runApp(
    DevicePreview(
      enabled: true,
      builder: (context) => MainApp(),
    ),
  );
}


class MainApp extends StatelessWidget {
  const MainApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Navegação',
      initialRoute: 'login',
      routes: {
        'login' :(context) => LoginView(),
        'CrUs' :(context) => CrUsView(),
        'App'   :(context) => AppView(),
        'sobre' :(context) => SobreView(),
        'Nvlist' :(context) => NvListView(),
        'listas' :(context) => ListasView(),
        'LstComp' :(context) => LstCompView(),
        'NovItm' :(context) => NvItmView(),
        'Mudar Nome' :(context) => MNomeView(),
        'Mudar Item' :(context) => MItemView(),
      },
    );
  }
}