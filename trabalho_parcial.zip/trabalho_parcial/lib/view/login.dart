// ignore_for_file: prefer_const_constructors

import 'package:flutter/material.dart';
import 'package:trabalho_parcial/model/usuario.dart';


class LoginView extends StatefulWidget {
  const LoginView({super.key});

  @override
  State<LoginView> createState() => _LoginViewState();
}

class _LoginViewState extends State<LoginView> {
  List<Usuario> lista = Usuario.listarLista();

  var formKey = GlobalKey<FormState>();
  var email = TextEditingController();
  var senha = TextEditingController();
  int j = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      
      appBar: AppBar(
        title: Text(
          'Login',
          style: TextStyle(color: Colors.white),
          ),
        backgroundColor: const Color.fromARGB(255, 20, 42, 80),
        automaticallyImplyLeading: false,
      ),
      body: Padding(
        padding: const EdgeInsets.fromLTRB(50, 100, 50, 100),
        child: SingleChildScrollView(
          child: Form(
          key: formKey,
            child: Column(
      
          children: [

                Icon(
                  Icons.shopping_cart_outlined,
                  size: 120,
                  color: Colors.black,
                ),
            
            SizedBox(height: 30),
            TextFormField(
              controller: email,
              keyboardType: TextInputType.emailAddress,
              style: TextStyle(color: Colors.black),
              decoration: InputDecoration(
              labelText: 'Email',
              labelStyle: TextStyle(color: Colors.black),
              fillColor: Colors.black,
                focusedBorder: OutlineInputBorder(
                  borderSide: BorderSide(
                    color: Colors.black,
                  ),
                ),
                enabledBorder: OutlineInputBorder(
                  borderSide: BorderSide(
                    color: Colors.black,
                    width: 2.0,
                  ),
                ),
              ),
              validator: (value) {
                if(value == null || value.isEmpty){
                  return 'Informe seu Email';
                }
                return null;
              },
                      
            ),

            SizedBox(height: 30),
            TextFormField(
              controller: senha,
              keyboardType: TextInputType.visiblePassword,
              obscureText: true,
              style: TextStyle(color: Colors.black),
              decoration: InputDecoration(
              labelText: 'Senha',
              labelStyle: TextStyle(color: Colors.black),
              fillColor: Colors.black,
                focusedBorder: OutlineInputBorder(
                  borderSide: BorderSide(
                    color: Colors.black,
                  ),
                ),
                enabledBorder: OutlineInputBorder(
                  borderSide: BorderSide(
                    color: Colors.black,
                    width: 2.0,
                  ),
                ),
              ),
              validator: (value) {
                if(value == null || value.isEmpty){
                  return 'Informe sua Senha';
                }
                return null;
              },
                        
            ),
           SizedBox(height: 30),
           Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
             children: [
               OutlinedButton(
                 style: OutlinedButton.styleFrom(
                    backgroundColor: Colors.white,
                    foregroundColor: Colors.black,
                  ),
                  onPressed: () {
                    //
                    //NAVEGAR para App
                    //                    
                   if (formKey.currentState!.validate()) {
                    j=0;
                    for(int i=0;i<lista.length;i++){
                     if(lista[i].email == email.text && lista[i].senha == senha.text){
                        email.clear();
                        senha.clear(); 
                         j=1; 
                      Navigator.pushNamed(
                      context, 
                      'App'
                       );
                     }                    
                    }
                    if(j==0){
                      showDialog(
                        context: context,
                            builder: (BuildContext context) => AlertDialog(
                              title: const Text('Usuário ou senha incorretos'),
                              actions: [
                              Row(
                                children: [
                                  TextButton(
                                    onPressed: () => Navigator.pop(context, 'OK'),
                                    child: const Text('OK'),
                                  ),
                                  TextButton(
                                    onPressed: () { 
                                      Navigator.pop(
                                        context, 
                                        'Criar usuário'
                                        );
                                      Navigator.pushNamed(
                                        context, 
                                        'CrUs'
                                        );
                                    },
                                    child: const Text('Criar usuário'),
                                  ),
                                ],
                              ),
                              ],
                            ),
                        ); 
                      }
                    }
                  },
                  child: Text('Entrar'),
                ),
                OutlinedButton(
                    style: OutlinedButton.styleFrom(
                    backgroundColor: Colors.white,
                    foregroundColor: Colors.black,
                  ),
                  onPressed: () {
                //
                //NAVEGAR para Criar usuário
                //
                Navigator.pushNamed(
                  context, 
                  'CrUs'
                  );
               
                  },
                  child: Text('Criar Usuário'),
                ),

             ],
           ),
          ],
         ),
        ),
       ),
      ),
    );
  }
}