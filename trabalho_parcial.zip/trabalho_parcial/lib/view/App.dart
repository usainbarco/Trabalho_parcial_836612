// ignore_for_file: prefer_const_constructors

import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';


class AppView extends StatefulWidget {
  const AppView({super.key});


  @override
  State<AppView> createState() => _AppViewState();
}

class _AppViewState extends State<AppView> {
  var formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      
      appBar: AppBar(
        title: Text(
          'Tela Principal',
          style: TextStyle(color: Colors.white),
          ),
        backgroundColor: const Color.fromARGB(255, 20, 42, 80),
      ),
      body: Padding(
        padding: const EdgeInsets.fromLTRB(90, 100, 50, 100),
        child: SingleChildScrollView(
          child: Form(
          key: formKey,
            child: Column(
      
            children: [

           Column(
            
             children: [
               OutlinedButton(
                 style: OutlinedButton.styleFrom(
                    backgroundColor: Colors.white,
                    foregroundColor: Colors.black,
                  ),
                  onPressed: () {
                    //
                    //NAVEGAR para listas
                    //                    
                      Navigator.pushNamed(
                      context, 
                      'listas'
                       );
                  },
                  child: Text('Editar/Visualizar Listas'),
                ),
                SizedBox(height: 30),
                OutlinedButton(
                    style: OutlinedButton.styleFrom(
                    backgroundColor: Colors.white,
                    foregroundColor: Colors.black,
                  ),
                  onPressed: () {
                //
                //NAVEGAR para Criar lista
                //
                Navigator.pushNamed(
                  context, 
                  'Nvlist'
                  );
               
                  },
                  child: Text('Nova Lista'),
                ),
                SizedBox(height: 30),
                OutlinedButton(
                        style: OutlinedButton.styleFrom(
                        backgroundColor: Colors.white,
                        foregroundColor: Colors.black,
                      ),
                      onPressed: () {
                    //
                    //NAVEGAR para Criar usuário
                    //
                    Navigator.pushNamed(
                      context, 
                      'sobre'
                      );
                                   
                      },
                      child: Text('Sobre'),
                    ),
             ],
           ),
          ],
         ),
        ),
       ),
      ),
    );
  }
}