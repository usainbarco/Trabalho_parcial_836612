// ignore_for_file: prefer_const_constructors

import 'package:flutter/material.dart';
import 'package:trabalho_parcial/model/compras.dart';

class ListasView extends StatefulWidget {
   const ListasView({super.key});

  @override
  State<ListasView> createState() => _ListasViewState();
}


class _ListasViewState extends State<ListasView> {
  List<Nomes> lista = [];
  int k=0;
  @override
  void initState() {
    lista = Nomes.listarLista2();
    super.initState();
  }
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
         title: Text(
          'Listas de compras',
          style: TextStyle(color: Colors.white),
          ),
        backgroundColor: const Color.fromARGB(255, 20, 42, 80),
      ),
      body: Padding(
        padding: EdgeInsets.all(20),
        //
        // ListView
        //
        child: ListView.builder(     
          //Quantidade de itens
          itemCount: lista.length,
          //Aparência de cada item
          itemBuilder: (context, index) {
            return Card(
              color: Colors.blue.shade50,
              child: ListTile(
                leading: Icon(Icons.shopping_basket),
                title: Text(lista[index].nom),

                hoverColor: Colors.red.shade50,
                //pressionar um item da lista
                onTap: () {
                    Navigator.pushNamed(
                     context, 
                     'LstComp',
                     arguments: lista[index].nom,
                  );
                },
                onLongPress: (){
                    showDialog(
  	                  context: context,
                          builder: (BuildContext context) => AlertDialog(
                            title: const Text('Opções'),
                            actions: [
                            Column(
                              children: [
                              SizedBox(height: 10),
                                OutlinedButton(
                                  onPressed: () { Navigator.pushNamed(
                                    context, 
                                    'Mudar Nome',
                                    arguments: lista[index].nom,
                                    );                                    
                                   },
                                  child: const Text('Mudar Nome'),                                  
                                 ),
                                SizedBox(height: 10),
                                OutlinedButton(
                                  onPressed: () { 
                                    Compras.Remover(lista[index].nom);
                                      setState(() {
                                        lista.removeAt(index);
                                      });
                                    Navigator.pop(context, 'Deletar lista');
                                    },
                                  child: const Text('Deletar lista'),
                                 ),
                                SizedBox(height: 10),
                                 OutlinedButton(
                                  onPressed: () { 
                                    Navigator.pop(context, 'Voltar');
                                    },
                                  child: const Text('Voltar'),
                                 ),
                              ],
                            ),
                            ],
                          ),
                       );

                },
              ),
            );
          },
        ),
      ),
    );
  }
}

