// ignore_for_file: prefer_const_constructors

import 'package:flutter/material.dart';
import 'package:trabalho_parcial/model/compras.dart';

class LstCompView extends StatefulWidget {
  const LstCompView({super.key});

  @override
  State<LstCompView> createState() => _LstCompViewState();
}


class _LstCompViewState extends State<LstCompView> {
  List<Itens> lista = [];
  List<Compras> lista2 =[]; 
  var item = TextEditingController();

  @override
  void initState() {
    lista2 = Compras.listarLista();
    super.initState();
  }


  @override
  Widget build(BuildContext context) {
  final nome = ModalRoute.of(context)!.settings.arguments;
   lista = Compras.itm(nome);
    return Scaffold(
      appBar: AppBar(
        title: Text(
        'Lista ${nome??''}',
        style: TextStyle(color: Colors.white),
        ),
         backgroundColor: const Color.fromARGB(255, 20, 42, 80),
      ),
      body: Padding(
        padding: EdgeInsets.all(20),
        //
        // ListView
        //
        child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
            Expanded(             
              child: ListView.builder(
              //Quantidade de itens
              itemCount: lista.length,
              //Aparência de cada item
              itemBuilder: (context, index) {
                return Card(
                  color: Colors.blue.shade50,
                  child: ListTile( 
                    title: Text(lista[index].item),
                    subtitle: Text('Quantidade: ${lista[index].quantidade ??''}'),

                    //pressionar um item da lista
                    onLongPress: (){
                    showDialog(
  	                  context: context,
                          builder: (BuildContext context) => AlertDialog(
                            title: const Text('Opções'),
                            actions: [
                            Column(
                              children: [
                              SizedBox(height: 10),
                                OutlinedButton(
                                  onPressed: () {                                    
                                    Navigator.pushNamed(
                                    context, 
                                    'Mudar Item',
                                    arguments: Compras.Busca(nome,lista[index].item,lista[index].quantidade),                                    
                                    );                                    
                                   },
                                  child: const Text('Alterar Item'),                                  
                                 ),
                                SizedBox(height: 10),
                                OutlinedButton(
                                  onPressed: () { 
                                    Compras.Removerind(nome,lista[index].item,lista[index].quantidade);
                                      setState(() {
                                        lista.removeAt(index);
                                      });
                                    Navigator.pop(context, 'Deletar item');
                                    },
                                  child: const Text('Deletar item'),
                                 ),
                                SizedBox(height: 10),
                                 OutlinedButton(
                                  onPressed: () { 
                                    Navigator.pop(context, 'Voltar');
                                    },
                                  child: const Text('Voltar'),
                                 ),
                              ],
                            ),
                            ],
                          ),
                       );
                    },
                  ),
                );
              },
             ),
            ),
          OutlinedButton(
            child: Text("Novo item"),
            onPressed: () {
                    Navigator.pushNamed(
                     context, 
                     'NovItm',
                     arguments: nome,
                  );
            },
          ),
          ],
        ),
      ),
    );
  }
}
