// ignore_for_file: prefer_const_constructors

import 'package:flutter/material.dart';
import 'package:trabalho_parcial/model/usuario.dart';

class CrUsView extends StatefulWidget {
  const CrUsView({super.key});

  @override
  State<CrUsView> createState() => _CrUsViewState();
}

class _CrUsViewState extends State<CrUsView> {
  
  var formKey = GlobalKey<FormState>();
  final email = TextEditingController();
  final senha = TextEditingController();
  final nome = TextEditingController();
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      
      appBar: AppBar(
        title: Text(
          'Criar Usuário',
          style: TextStyle(color: Colors.white),
          ),
        backgroundColor: const Color.fromARGB(255, 20, 42, 80),
        automaticallyImplyLeading: false,
      ),
      body: Padding(
        padding: const EdgeInsets.fromLTRB(50, 100, 50, 100),
        child: SingleChildScrollView(
          child: Form(
          key: formKey,
            child: Column(
      
          children: [
            
            TextFormField(
              controller: nome,
              keyboardType: TextInputType.name,
              style: TextStyle(color: Colors.black),
              decoration: InputDecoration(
              labelText: 'Nome',
              labelStyle: TextStyle(color: Colors.black),
              fillColor: Colors.black,
                focusedBorder: OutlineInputBorder(
                  borderSide: BorderSide(
                    color: Colors.black,
                  ),
                ),
                enabledBorder: OutlineInputBorder(
                  borderSide: BorderSide(
                    color: Colors.black,
                    width: 2.0,
                  ),
                ),
              ),
              validator: (value) {
                if(value == null || value.isEmpty){
                  return 'Informe seu Nome';
                }
                return null;
              },
                     
            ),
            
            SizedBox(height: 30),
            TextFormField(
              controller: email,
              keyboardType: TextInputType.emailAddress,
              style: TextStyle(color: Colors.black),
              decoration: InputDecoration(
              labelText: 'Email',
              labelStyle: TextStyle(color: Colors.black),
              fillColor: Colors.black,
                focusedBorder: OutlineInputBorder(
                  borderSide: BorderSide(
                    color: Colors.black,
                  ),
                ),
                enabledBorder: OutlineInputBorder(
                  borderSide: BorderSide(
                    color: Colors.black,
                    width: 2.0,
                  ),
                ),
              ),
              validator: (value) {
                if(value == null || value.isEmpty){
                  return 'Informe seu Email';
                }
                return null;
              },
                     
            ),

            SizedBox(height: 30),
            TextFormField(
              controller: senha,
              keyboardType: TextInputType.visiblePassword,
              obscureText: true,
              style: TextStyle(color: Colors.black),
              decoration: InputDecoration(
              labelText: 'Senha',
              labelStyle: TextStyle(color: Colors.black),
              fillColor: Colors.black,
                focusedBorder: OutlineInputBorder(
                  borderSide: BorderSide(
                    color: Colors.black,
                  ),
                ),
                enabledBorder: OutlineInputBorder(
                  borderSide: BorderSide(
                    color: Colors.black,
                    width: 2.0,
                  ),
                ),
              ),
              validator: (value) {
                if(value == null || value.isEmpty){
                  return 'Informe sua Senha';
                }
                return null;
              },
                    
            ),
           SizedBox(height: 30),
           Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
             children: [
               OutlinedButton(
                 style: OutlinedButton.styleFrom(
                    backgroundColor: Colors.white,
                    foregroundColor: Colors.black,
                  ),
                  onPressed: () {
                    //
                    //NAVEGAR para login
                    //
                   if (formKey.currentState!.validate()) {
                    Usuario.adcusr(nome.text, email.text, senha.text);
                    
                      Navigator.pop(context);   
                   }
                  },
                  child: Text('Criar'),
                ),
                OutlinedButton(
                    style: OutlinedButton.styleFrom(
                    backgroundColor: Colors.white,
                    foregroundColor: Colors.black,
                  ),
                  onPressed: () {
                //
                //Retornar
                //
                Navigator.pop(context);
               
                  },
                  child: Text('Voltar'),
                ),
             ],
           ),
          ],
         ),
        ),
       ),
      ),
    );
  }
}