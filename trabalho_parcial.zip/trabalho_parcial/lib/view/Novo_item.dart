// ignore_for_file: prefer_const_constructors

import 'package:flutter/material.dart';
import 'package:trabalho_parcial/model/compras.dart';

class NvItmView extends StatefulWidget {
  const NvItmView({super.key});

  @override
  State<NvItmView> createState() => _NvItmViewState();
}

class _NvItmViewState extends State<NvItmView> {
  
  var formKey = GlobalKey<FormState>();
  final item = TextEditingController();
  final quantidade = TextEditingController();
  
  @override
  Widget build(BuildContext context) {
  final listnom = ModalRoute.of(context)!.settings.arguments;
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Novo Item de ${listnom ??''}',
          style: TextStyle(color: Colors.white),
          ),
        backgroundColor: const Color.fromARGB(255, 20, 42, 80),
        automaticallyImplyLeading: false,
      ),
      body: Padding(
        padding: const EdgeInsets.fromLTRB(50, 100, 50, 100),
        child: SingleChildScrollView(
          child: Form(
          key: formKey,
            child: Column(
      
          children: [

                TextFormField(
                  controller: item,
                  keyboardType: TextInputType.text,
                  style: TextStyle(color: Colors.black),
                  decoration: InputDecoration(
                  labelText: 'Item',
                  labelStyle: TextStyle(color: Colors.black),
                  fillColor: Colors.black,
                    focusedBorder: OutlineInputBorder(
                      borderSide: BorderSide(
                        color: Colors.black,
                      ),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(
                        color: Colors.black,
                        width: 1.0,
                      ),
                    ),
                  ),
                  validator: (value) {
                    if(value == null || value.isEmpty){
                      return 'Informe o item';
                    }
                    return null;
                  },
                         
                ),
                
                SizedBox(height: 30),
                TextFormField(
                  controller: quantidade,
                  keyboardType: TextInputType.number,
                  style: TextStyle(color: Colors.black),
                  decoration: InputDecoration(
                  labelText: 'Quantidade',
                  labelStyle: TextStyle(color: Colors.black),
                  fillColor: Colors.black,
                    focusedBorder: OutlineInputBorder(
                      borderSide: BorderSide(
                        color: Colors.black,
                      ),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(
                        color: Colors.black,
                        width: 1.0,
                      ),
                    ),
                  ),
                  validator: (value) {
                    if(value == null || value.isEmpty){
                      return 'Informe a quantidade';
                    }else if (double.tryParse(value) == null) {
                      return 'Informe um numero';
                    }
                    return null;
                  },
                        
                ),
           SizedBox(height: 30),
           Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
             children: [
               OutlinedButton(
                 style: OutlinedButton.styleFrom(
                    backgroundColor: Colors.white,
                    foregroundColor: Colors.black,
                  ),
                  onPressed: () {
                    //
                    //Adicionar Item
                    //
                   if (formKey.currentState!.validate()) {
                    Compras.adcitm(listnom, item.text, quantidade.text);
                    
                    item.clear();
                    quantidade.clear();   

                     showDialog(
  	                  context: context,
                          builder: (BuildContext context) => AlertDialog(
                            title: const Text('Item adicionado com sucesso'),
                            actions: [
                            TextButton(
                              onPressed: () => Navigator.pop(context, 'OK'),
                              child: const Text('OK'),
                             ),
                            ],
                          ),
                       ); 
                      }                                       
                    },
                  child: Text('Novo item'),
                ),
                OutlinedButton(
                    style: OutlinedButton.styleFrom(
                    backgroundColor: Colors.white,
                    foregroundColor: Colors.black,
                  ),
                  onPressed: () {
                //
                //Retornar
                //
                Navigator.pop(context);  
                },
                  child: Text('Retornar'),
                ),
             ],
           ),
          ],
         ),
        ),
       ),
      ),
    );
  }
}