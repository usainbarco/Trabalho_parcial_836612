// ignore_for_file: prefer_const_constructors

import 'package:flutter/material.dart';
import 'package:trabalho_parcial/model/compras.dart';

class NvListView extends StatefulWidget {
  const NvListView({super.key});

  @override
  State<NvListView> createState() => _NvListViewState();
}

class _NvListViewState extends State<NvListView> {
  List<Compras> lista =[];
  var formKey = GlobalKey<FormState>();
  final listnom = TextEditingController();
  int j=0;
  @override
  void initState() {
    lista = Compras.listarLista();
    super.initState();
  }

  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      
      appBar: AppBar(
        title: Text(
          'Criar Lista',
          style: TextStyle(color: Colors.white),
          ),
        backgroundColor: const Color.fromARGB(255, 20, 42, 80),
        automaticallyImplyLeading: false,
      ),
      body: Padding(
        padding: const EdgeInsets.fromLTRB(50, 100, 50, 100),
        child: SingleChildScrollView(
          child: Form(
          key: formKey,
            child: Column(
      
          children: [
            
            TextFormField(
              controller: listnom,
              keyboardType: TextInputType.name,
              style: TextStyle(color: Colors.black),
              decoration: InputDecoration(
              labelText: 'Nome da lista',
              labelStyle: TextStyle(color: Colors.black),
              fillColor: Colors.black,
                focusedBorder: OutlineInputBorder(
                  borderSide: BorderSide(
                    color: Colors.black,
                  ),
                ),
                enabledBorder: OutlineInputBorder(
                  borderSide: BorderSide(
                    color: Colors.black,
                    width: 2.0,
                  ),
                ),
              ),
              validator: (value) {
                if(value == null || value.isEmpty){
                  return 'Informe o nome da lista';
                }
                return null;
              },
                     
            ),
            
           SizedBox(height: 30),
           Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
             children: [
               OutlinedButton(
                 style: OutlinedButton.styleFrom(
                    backgroundColor: Colors.white,
                    foregroundColor: Colors.black,
                  ),
                  onPressed: () {
                    //
                    //Criar lista
                    //
                   if (formKey.currentState!.validate()) {
                    j=0;
                    for(int i=0;i<lista.length;i++){
                     if(lista[i].listnom == listnom.text){
                    listnom.clear();
                      showDialog(
  	                  context: context,
                          builder: (BuildContext context) => AlertDialog(
                            title: const Text('Lista Existente'),
                            actions: [
                            TextButton(
                              onPressed: () => Navigator.pop(context, 'OK'),
                              child: const Text('OK'),
                             ),
                            ],
                          ),
                       );
                      j=1;
                     }                    
                    }if(j==0){
                    Compras.adcitm(listnom.text, 'null', 'null');
                    Compras.adcitm(listnom.text, 'loremipsum', 'loremipsum');
                    listnom.clear();   

                     showDialog(
  	                  context: context,
                          builder: (BuildContext context) => AlertDialog(
                            title: const Text('Lista criada com sucesso'),
                            actions: [
                            TextButton(
                              onPressed: () => Navigator.pop(context, 'OK'),
                              child: const Text('OK'),
                             ),
                            ],
                          ),
                        );
                       }
                      }                                       
                    },
                  child: Text('Criar Lista'),
                ),
                OutlinedButton(
                    style: OutlinedButton.styleFrom(
                    backgroundColor: Colors.white,
                    foregroundColor: Colors.black,
                  ),
                  onPressed: () {
                //
                //Criar
                //
                Navigator.pop(context);  
                },
                  child: Text('Retornar'),
                ),
             ],
           ),
          ],
         ),
        ),
       ),
      ),
    );
  }
}