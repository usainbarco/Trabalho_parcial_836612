// ignore_for_file: prefer_const_constructors

import 'package:flutter/material.dart';
import 'package:trabalho_parcial/model/compras.dart';

class MItemView extends StatefulWidget {
  const MItemView({super.key});

  @override
  State<MItemView> createState() => _MItemViewState();
}

class _MItemViewState extends State<MItemView> {
  
  var formKey = GlobalKey<FormState>();
  final item = TextEditingController();
  final quantidade = TextEditingController();
  
  @override
  Widget build(BuildContext context) {
  final index = ModalRoute.of(context)!.settings.arguments;
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Alterar item',
          style: TextStyle(color: Colors.white),
          ),
        backgroundColor: const Color.fromARGB(255, 20, 42, 80),
        automaticallyImplyLeading: false,
      ),
      body: Padding(
        padding: const EdgeInsets.fromLTRB(50, 100, 50, 100),
        child: SingleChildScrollView(
          child: Form(
          key: formKey,
            child: Column(
      
          children: [

                TextFormField(
                  controller: item,
                  keyboardType: TextInputType.name,
                  style: TextStyle(color: Colors.black),
                  decoration: InputDecoration(
                  labelText: 'Novo item',
                  labelStyle: TextStyle(color: Colors.black),
                  fillColor: Colors.black,
                    focusedBorder: OutlineInputBorder(
                      borderSide: BorderSide(
                        color: Colors.black,
                      ),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(
                        color: Colors.black,
                        width: 1.0,
                      ),
                    ),
                  ),
                  validator: (value) {
                    if(value == null || value.isEmpty){
                      return 'Informe o novo item';
                    }
                    return null;
                  },
                         
                ),
               SizedBox(height: 30),
                 TextFormField(
                  controller: quantidade,
                  keyboardType: TextInputType.number,
                  style: TextStyle(color: Colors.black),
                  decoration: InputDecoration(
                  labelText: 'Nova quantidade',
                  labelStyle: TextStyle(color: Colors.black),
                  fillColor: Colors.black,
                    focusedBorder: OutlineInputBorder(
                      borderSide: BorderSide(
                        color: Colors.black,
                      ),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(
                        color: Colors.black,
                        width: 1.0,
                      ),
                    ),
                  ),
                  validator: (value) {
                    if(value == null || value.isEmpty){
                      return 'Informe a nova quantidade';
                    }else if (double.tryParse(value) == null) {
                      return 'Informe um numero';
                    }
                    return null;
                  },
                         
                ),
                
           SizedBox(height: 30),
           Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
             children: [
               OutlinedButton(
                 style: OutlinedButton.styleFrom(
                    backgroundColor: Colors.white,
                    foregroundColor: Colors.black,
                  ),
                  onPressed: () {
                    //
                    //Alterar Item
                    //
                   if (formKey.currentState!.validate()) {
                    
                    Compras.MItem(index, item.text, quantidade.text);
    
                     showDialog(
  	                  context: context,
                          builder: (BuildContext context) => AlertDialog(
                            title: const Text('Item alterado'),
                            actions: [
                            TextButton(
                              onPressed: (){Navigator.popUntil(
                                context, 
                                ModalRoute.withName('App')
                                );
                                Navigator.pushNamed(
                                  context,
                                 'listas'
                                );
                              },
                              child: const Text('OK'),
                             ),
                            ],
                          ),
                       ); 
                      }                                       
                    },
                  child: Text('Mudar Item'),
                ),
                OutlinedButton(
                    style: OutlinedButton.styleFrom(
                    backgroundColor: Colors.white,
                    foregroundColor: Colors.black,
                  ),
                  onPressed: () {
                //
                //Retornar
                //
                Navigator.pop(context);  
                },
                  child: Text('Retornar'),
                ),
             ],
           ),
          ],
         ),
        ),
       ),
      ),
    );
  }
}