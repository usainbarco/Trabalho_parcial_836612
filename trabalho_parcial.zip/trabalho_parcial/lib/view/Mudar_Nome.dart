// ignore_for_file: prefer_const_constructors

import 'package:flutter/material.dart';
import 'package:trabalho_parcial/model/compras.dart';

class MNomeView extends StatefulWidget {
  const MNomeView({super.key});

  @override
  State<MNomeView> createState() => _MNomeViewState();
}

class _MNomeViewState extends State<MNomeView> {
  
  var formKey = GlobalKey<FormState>();
  final Mnom = TextEditingController();
  
  @override
  Widget build(BuildContext context) {
  final listnom = ModalRoute.of(context)!.settings.arguments;
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Mudar nome de ${listnom ??''}',
          style: TextStyle(color: Colors.white),
          ),
        backgroundColor: const Color.fromARGB(255, 20, 42, 80),
        automaticallyImplyLeading: false,
      ),
      body: Padding(
        padding: const EdgeInsets.fromLTRB(50, 100, 50, 100),
        child: SingleChildScrollView(
          child: Form(
          key: formKey,
            child: Column(
      
          children: [

                TextFormField(
                  controller: Mnom,
                  keyboardType: TextInputType.name,
                  style: TextStyle(color: Colors.black),
                  decoration: InputDecoration(
                  labelText: 'Novo nome',
                  labelStyle: TextStyle(color: Colors.black),
                  fillColor: Colors.black,
                    focusedBorder: OutlineInputBorder(
                      borderSide: BorderSide(
                        color: Colors.black,
                      ),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(
                        color: Colors.black,
                        width: 1.0,
                      ),
                    ),
                  ),
                  validator: (value) {
                    if(value == null || value.isEmpty){
                      return 'Informe o novo nome';
                    }
                    return null;
                  },
                         
                ),
                
           SizedBox(height: 30),
           Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
             children: [
               OutlinedButton(
                 style: OutlinedButton.styleFrom(
                    backgroundColor: Colors.white,
                    foregroundColor: Colors.black,
                  ),
                  onPressed: () {
                    //
                    //Alterar nome
                    //
                   if (formKey.currentState!.validate()) {
                    
                    Compras.MNome(listnom, Mnom.text);
                    Nomes.MNome(listnom, Mnom.text);
                    Mnom.clear();
    
                     showDialog(
  	                  context: context,
                          builder: (BuildContext context) => AlertDialog(
                            title: const Text('Nome alterado'),
                            actions: [
                            TextButton(
                              onPressed: () { Navigator.popUntil(
                                context, 
                                ModalRoute.withName('App')
                                );
                                Navigator.pushNamed(
                                  context,
                                 'listas'
                                );
                              },
                              child: const Text('OK'),
                             ),
                            ],
                          ),
                       ); 
                      }                                       
                    },
                  child: Text('Mudar nome'),
                ),
                OutlinedButton(
                    style: OutlinedButton.styleFrom(
                    backgroundColor: Colors.white,
                    foregroundColor: Colors.black,
                  ),
                  onPressed: () {
                //
                //Retornar
                //
                Navigator.pop(context);  
                },
                  child: Text('Retornar'),
                ),
             ],
           ),
          ],
         ),
        ),
       ),
      ),
    );
  }
}