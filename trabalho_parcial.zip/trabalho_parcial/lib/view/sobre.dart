import 'package:flutter/material.dart';

class SobreView extends StatefulWidget {
   const SobreView({super.key});

  @override
  State<SobreView> createState() => _SobreViewState();
}


class _SobreViewState extends State<SobreView> { 

  @override
  void initState() {    
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
         title: Text(
            'Sobre',
             style: TextStyle(color: Colors.white),
            ),
        backgroundColor: const Color.fromARGB(255, 20, 42, 80),
      ),
      body: Padding( 
      padding: const EdgeInsets.fromLTRB(50, 50, 50, 100),
      child: Column(
        children: [
        Text('Aplicativo de lista de compras.'),
        Text('Objetivo: Criar listas de compras digitais'),
        Text('para melhorar sua organização no dia a dia'),
        Text('Vinicius dos Santos Salgado / 836612'),
        ],
       ),
      ),
    );
  }
}