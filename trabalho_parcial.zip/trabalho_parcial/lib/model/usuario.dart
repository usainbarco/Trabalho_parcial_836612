class Usuario {
  final String nome;
  final String email;
  final String senha;

  Usuario(this.nome, this.email, this.senha);
  static List<Usuario> lista = [];

  static List<Usuario> adcusr(nome,email,senha) {
  lista.add(Usuario(nome, email, senha));
  
  return lista;
  }
  static List<Usuario> listarLista() {

  return lista;
  }
  
}
