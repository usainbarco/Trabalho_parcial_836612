class Compras {
  String listnom;
  String item;
  String quantidade;

  Compras(this.listnom, this.item, this.quantidade);

  static List<Compras> lista = [];
  static List<Itens> lista3 =[];
  static List<Nomes> lista2 =[];

  static List<Compras> adcitm(listnom, item, quantidade) {
  lista.add(Compras(listnom, item, quantidade));
  Nomes.adcnom(listnom);
  return lista;
  }

  static List<Compras> listarLista() {

  return lista;
  }

  static List<Itens> itm(nome){
    lista3.clear();
    for(int i=0;i<lista.length;i++){
      if(lista[i].item =='null'){
        i++;
      }else if(nome==lista[i].listnom){ 
        lista3.add(Itens(lista[i].item,lista[i].quantidade));
      }
  }
  return lista3;
}
  
  static List<Compras> MNome(listnom,Mnom){
    for(int i=0;i<lista.length;i++){
      if(listnom==lista[i].listnom){ 
        lista[i].listnom = Mnom;        
      }
  }
  return lista;
}
  static List<Compras> MItem(index,item,quantidade){
    for(int i=0;i<lista.length;i++){
      if(index==i){ 
        lista[i].item = item; 
        lista[i].quantidade = quantidade;       
      }
  }
  return lista;
}
static List<Compras> Remover(listnom){
   for(int i=0;i<lista.length;i++){
      if(listnom==lista[i].listnom){
        lista.removeAt(i);
        i--;
      }
    }
return lista;
}

static int Busca(listnom,item,quantidade){
    for(int i=0;i<lista.length;i++){
      if(listnom==lista[i].listnom && item==lista[i].item && quantidade==lista[i].quantidade){
        return i;
      }
    }
  return 0;
}
static List<Compras> Removerind(listnom,item,quantidade){
    for(int i=0;i<lista.length;i++){
      if(listnom==lista[i].listnom && item==lista[i].item && quantidade==lista[i].quantidade){
        lista.removeAt(i);
      }
    }
return lista;
}

}

class Nomes {
  String nom;

  Nomes(this.nom);
  
  static List<Nomes> lista2 = [];

  static List<Nomes> adcnom(nom) {
  int j=0;
  if(lista2.length == 0){
    lista2.add(Nomes(nom));
  }else{
    for(int i=0;i<lista2.length;i++){
      if(nom==lista2[i].nom){
        j++;
      }
  }
  if(j==0){
    lista2.add(Nomes(nom));
    
  }
  }
  return lista2;
  }
  static List<Nomes> listarLista2() {
    
  return lista2;
  }

  static List<Nomes> MNome(listnom,Mnom){
    for(int i=0;i<lista2.length;i++){
      if(listnom==lista2[i].nom){ 
        lista2[i].nom = Mnom;        
      }
  }
  return lista2;
}
}

class Itens {
   String item;
   String quantidade;

  Itens(this.item, this.quantidade);

  List<Itens> lista3 =[];
}